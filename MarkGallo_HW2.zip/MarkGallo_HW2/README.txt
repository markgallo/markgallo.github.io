Crawled_websites_qmss_columbia -> text files from "gmss columbia search"
Crawled -> files from 4 chosen searches
Pandas df of "Crawled" -> see HW2 ipynb
Answers to written questions can be found in HW2 ipynb
 